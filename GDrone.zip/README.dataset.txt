# GDrone > 2022-07-29 3:18pm
https://universe.roboflow.com/object-detection/gdrone

Provided by Roboflow
License: CC BY 4.0

